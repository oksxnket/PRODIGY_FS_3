# Security Policy

## Reporting a Vulnerability

If you discover a security vulnerability, please **do not open a public issue**.

Instead, send a detailed email to [modhahrutav@gmail.com].

I'll review the issue and respond as quickly as possible.
